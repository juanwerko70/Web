import os
import re
import secrets
from datetime import datetime, timedelta
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, abort
from flask_sqlalchemy import SQLAlchemy
from flask_wtf.csrf import CSRFProtect
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import or_, func, text
from sqlalchemy.exc import IntegrityError
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address


def normalize_database_url(url: str) -> str:
    if url.startswith("postgres://"):
        return url.replace("postgres://", "postgresql+psycopg://", 1)
    if url.startswith("postgresql://"):
        return url.replace("postgresql://", "postgresql+psycopg://", 1)
    return url


app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("SECRET_KEY") or secrets.token_urlsafe(48),
    SQLALCHEMY_DATABASE_URI=normalize_database_url(os.environ.get("DATABASE_URL", "sqlite:///cart3r.db")),
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    SQLALCHEMY_ENGINE_OPTIONS={"pool_pre_ping": True},
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "1" if os.environ.get("RAILWAY_ENVIRONMENT_NAME") else "0") == "1",
    PERMANENT_SESSION_LIFETIME=timedelta(days=7),
    MAX_CONTENT_LENGTH=2 * 1024 * 1024,
)

db = SQLAlchemy(app)
CSRFProtect(app)
limiter = Limiter(get_remote_address, app=app, default_limits=[], storage_uri=os.environ.get("RATELIMIT_STORAGE_URI", "memory://"))


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(32), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    credits = db.Column(db.Integer, default=100, nullable=False)
    is_admin = db.Column(db.Boolean, default=False, nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


class Project(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"), nullable=False, index=True)
    name = db.Column(db.String(80), nullable=False)
    description = db.Column(db.String(300), default="")
    status = db.Column(db.String(20), default="Activo", nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


class CreditEvent(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"), nullable=False, index=True)
    amount = db.Column(db.Integer, nullable=False)
    reason = db.Column(db.String(120), nullable=False)
    actor_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


class SavedSnippet(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"), nullable=False, index=True)
    title = db.Column(db.String(80), nullable=False)
    language = db.Column(db.String(20), default="python")
    code = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


class LoginAttempt(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    identity = db.Column(db.String(120), nullable=False, index=True)
    ip_address = db.Column(db.String(64), nullable=False, index=True)
    succeeded = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


def current_user():
    uid = session.get("user_id")
    user = db.session.get(User, uid) if uid else None
    if user and not user.is_active:
        session.clear()
        return None
    return user


@app.context_processor
def inject_user():
    return {"current_user": current_user()}


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            flash("Inicia sesión para continuar.", "warning")
            return redirect(url_for("login", next=request.path))
        return fn(*args, **kwargs)
    return wrapper


def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapper(*args, **kwargs):
        if not current_user().is_admin:
            abort(403)
        return fn(*args, **kwargs)
    return wrapper


def record_credit(user_id, amount, reason, actor_id=None):
    user = db.session.get(User, user_id)
    if not user:
        raise ValueError("Usuario no encontrado")
    if user.credits + amount < 0:
        raise ValueError("El saldo no puede quedar negativo")
    user.credits += amount
    db.session.add(CreditEvent(user_id=user.id, amount=amount, reason=reason[:120], actor_id=actor_id))


@app.after_request
def security_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    response.headers.setdefault("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; script-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'")
    if request.is_secure or app.config["SESSION_COOKIE_SECURE"]:
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    return response


@app.get("/health")
def health():
    try:
        db.session.execute(text("SELECT 1"))
        return jsonify(status="ok", app="CART3R.JAILBREAK", version="2.0.0"), 200
    except Exception:
        app.logger.exception("Health check database failure")
        return jsonify(status="degraded"), 503


@app.route("/")
def index():
    if current_user():
        return redirect(url_for("dashboard"))
    return render_template("landing.html")


@app.route("/register", methods=["GET", "POST"])
@limiter.limit("5 per hour", methods=["POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not re.fullmatch(r"[A-Za-z0-9_]{3,32}", username):
            flash("El usuario debe tener 3–32 caracteres: letras, números o guion bajo.", "error")
        elif not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            flash("Introduce un correo válido.", "error")
        elif len(password) < 10 or len(password) > 128:
            flash("La contraseña debe tener entre 10 y 128 caracteres.", "error")
        elif User.query.filter(or_(User.username.ilike(username), User.email == email)).first():
            flash("Ese usuario o correo ya está registrado.", "error")
        else:
            admin_email = os.environ.get("ADMIN_EMAIL", "").strip().lower()
            user = User(username=username, email=email, password_hash=generate_password_hash(password), credits=100, is_admin=bool(admin_email and email == admin_email))
            db.session.add(user)
            db.session.flush()
            db.session.add(CreditEvent(user_id=user.id, amount=100, reason="Bono de bienvenida"))
            db.session.commit()
            session.clear()
            session.permanent = True
            session["user_id"] = user.id
            flash("Cuenta creada. Recibiste 100 créditos de bienvenida.", "success")
            return redirect(url_for("dashboard"))
    return render_template("auth.html", mode="register")


@app.route("/login", methods=["GET", "POST"])
@limiter.limit("10 per 15 minutes", methods=["POST"])
def login():
    if request.method == "POST":
        identity = request.form.get("identity", "").strip()
        user = User.query.filter(or_(User.username.ilike(identity), User.email == identity.lower())).first()
        valid = bool(user and user.is_active and check_password_hash(user.password_hash, request.form.get("password", "")))
        db.session.add(LoginAttempt(identity=identity[:120], ip_address=get_remote_address()[:64], succeeded=valid))
        db.session.commit()
        if valid:
            session.clear()
            session.permanent = True
            session["user_id"] = user.id
            flash("Sesión iniciada correctamente.", "success")
            target = request.args.get("next", "")
            if target.startswith("/") and not target.startswith("//"):
                return redirect(target)
            return redirect(url_for("dashboard"))
        flash("Credenciales incorrectas o cuenta desactivada.", "error")
    return render_template("auth.html", mode="login")


@app.post("/logout")
@login_required
def logout():
    session.clear()
    flash("Has cerrado sesión.", "success")
    return redirect(url_for("index"))


@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    projects = Project.query.filter_by(user_id=user.id).order_by(Project.created_at.desc()).limit(5).all()
    events = CreditEvent.query.filter_by(user_id=user.id).order_by(CreditEvent.created_at.desc()).limit(6).all()
    snippets_count = SavedSnippet.query.filter_by(user_id=user.id).count()
    return render_template("dashboard.html", projects=projects, events=events, snippets_count=snippets_count)


@app.route("/projects", methods=["GET", "POST"])
@login_required
def projects():
    user = current_user()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        desc = request.form.get("description", "").strip()
        if not name or len(name) > 80 or len(desc) > 300:
            flash("Revisa el nombre y la descripción del proyecto.", "error")
        else:
            db.session.add(Project(user_id=user.id, name=name, description=desc))
            db.session.commit()
            flash("Proyecto creado.", "success")
        return redirect(url_for("projects"))
    items = Project.query.filter_by(user_id=user.id).order_by(Project.created_at.desc()).all()
    return render_template("projects.html", projects=items)


@app.post("/projects/<int:project_id>/delete")
@login_required
def delete_project(project_id):
    item = Project.query.filter_by(id=project_id, user_id=current_user().id).first_or_404()
    db.session.delete(item)
    db.session.commit()
    flash("Proyecto eliminado.", "success")
    return redirect(url_for("projects"))


@app.post("/projects/<int:project_id>/status")
@login_required
def update_project_status(project_id):
    item = Project.query.filter_by(id=project_id, user_id=current_user().id).first_or_404()
    status = request.form.get("status", "")
    if status not in {"Activo", "En progreso", "Pausado", "Completado"}:
        abort(400)
    item.status = status
    db.session.commit()
    flash("Estado del proyecto actualizado.", "success")
    return redirect(url_for("projects"))


@app.route("/credits")
@login_required
def credits():
    user = current_user()
    events = CreditEvent.query.filter_by(user_id=user.id).order_by(CreditEvent.created_at.desc()).all()
    return render_template("credits.html", events=events)


@app.route("/code-lab", methods=["GET", "POST"])
@login_required
def code_lab():
    user = current_user()
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        language = request.form.get("language", "python")
        code = request.form.get("code", "")
        allowed_languages = {"python", "javascript", "html", "css", "sql", "bash", "otro"}
        if title and len(title) <= 80 and code and len(code) <= 20000 and language in allowed_languages:
            db.session.add(SavedSnippet(user_id=user.id, title=title, language=language, code=code))
            db.session.commit()
            flash("Fragmento guardado.", "success")
        else:
            flash("Revisa el título, lenguaje y longitud del código.", "error")
        return redirect(url_for("code_lab"))
    snippets = SavedSnippet.query.filter_by(user_id=user.id).order_by(SavedSnippet.created_at.desc()).all()
    return render_template("code_lab.html", snippets=snippets)


@app.post("/snippets/<int:snippet_id>/delete")
@login_required
def delete_snippet(snippet_id):
    item = SavedSnippet.query.filter_by(id=snippet_id, user_id=current_user().id).first_or_404()
    db.session.delete(item)
    db.session.commit()
    flash("Fragmento eliminado.", "success")
    return redirect(url_for("code_lab"))


@app.route("/security")
@login_required
def security():
    return render_template("security.html")


@app.route("/assistant", methods=["GET", "POST"])
@login_required
def assistant():
    answer = None
    if request.method == "POST":
        prompt = request.form.get("prompt", "").strip()[:1500]
        if prompt:
            answer = ("Asistente local de CART3R: organiza tu solicitud en objetivo, contexto y resultado esperado. "
                      "Para seguridad, trabaja únicamente con sistemas propios o con autorización explícita. "
                      "No ejecuto acciones externas ni accedo a cuentas de terceros. "
                      "Solicitud recibida: " + prompt)
    return render_template("assistant.html", answer=answer)


@app.route("/settings", methods=["GET", "POST"])
@login_required
def settings():
    user = current_user()
    if request.method == "POST":
        action = request.form.get("action")
        if action == "profile":
            username = request.form.get("username", "").strip()
            email = request.form.get("email", "").strip().lower()
            if not re.fullmatch(r"[A-Za-z0-9_]{3,32}", username) or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
                flash("Revisa el usuario y el correo.", "error")
            elif User.query.filter(User.id != user.id, or_(User.username.ilike(username), User.email == email)).first():
                flash("Ese usuario o correo ya está en uso.", "error")
            else:
                user.username, user.email = username, email
                if email == os.environ.get("ADMIN_EMAIL", "").strip().lower():
                    user.is_admin = True
                db.session.commit()
                flash("Perfil actualizado.", "success")
        elif action == "password":
            old_password = request.form.get("old_password", "")
            new_password = request.form.get("new_password", "")
            if not check_password_hash(user.password_hash, old_password):
                flash("La contraseña actual no coincide.", "error")
            elif len(new_password) < 10 or len(new_password) > 128:
                flash("La nueva contraseña debe tener entre 10 y 128 caracteres.", "error")
            else:
                user.password_hash = generate_password_hash(new_password)
                db.session.commit()
                flash("Contraseña actualizada.", "success")
        return redirect(url_for("settings"))
    return render_template("settings.html")


@app.route("/admin")
@admin_required
def admin_dashboard():
    stats = {
        "users": User.query.count(),
        "active_users": User.query.filter_by(is_active=True).count(),
        "projects": Project.query.count(),
        "snippets": SavedSnippet.query.count(),
        "credits": db.session.query(func.coalesce(func.sum(User.credits), 0)).scalar(),
        "failed_logins": LoginAttempt.query.filter_by(succeeded=False).filter(LoginAttempt.created_at >= datetime.utcnow() - timedelta(hours=24)).count(),
    }
    users = User.query.order_by(User.created_at.desc()).limit(12).all()
    return render_template("admin.html", stats=stats, users=users)


@app.post("/admin/users/<int:user_id>/credits")
@admin_required
def admin_adjust_credits(user_id):
    target = User.query.get_or_404(user_id)
    try:
        amount = int(request.form.get("amount", "0"))
        reason = request.form.get("reason", "Ajuste administrativo").strip()
        if amount == 0 or abs(amount) > 10000 or not reason:
            raise ValueError("Usa un ajuste entre -10.000 y 10.000 y escribe un motivo")
        record_credit(target.id, amount, "Admin: " + reason, actor_id=current_user().id)
        db.session.commit()
        flash("Saldo actualizado y movimiento registrado.", "success")
    except (ValueError, TypeError) as exc:
        db.session.rollback()
        flash(str(exc), "error")
    return redirect(url_for("admin_dashboard"))


@app.post("/admin/users/<int:user_id>/status")
@admin_required
def admin_toggle_user(user_id):
    target = User.query.get_or_404(user_id)
    if target.id == current_user().id:
        flash("No puedes desactivar tu propia cuenta.", "error")
    else:
        target.is_active = not target.is_active
        db.session.commit()
        flash("Estado de cuenta actualizado.", "success")
    return redirect(url_for("admin_dashboard"))


@app.errorhandler(403)
def forbidden(_):
    return render_template("error.html", code=403, message="No tienes permisos para acceder a esta sección."), 403


@app.errorhandler(404)
def not_found(_):
    return render_template("error.html", code=404, message="No encontramos esa página."), 404


@app.errorhandler(429)
def too_many_requests(_):
    return render_template("error.html", code=429, message="Demasiados intentos. Espera un momento y vuelve a intentarlo."), 429


@app.errorhandler(500)
def server_error(_):
    db.session.rollback()
    app.logger.exception("Unhandled server error")
    return render_template("error.html", code=500, message="Ocurrió un error interno."), 500


with app.app_context():
    db.create_all()
    LoginAttempt.query.filter(LoginAttempt.created_at < datetime.utcnow() - timedelta(days=30)).delete(synchronize_session=False)
    db.session.commit()
    admin_email = os.environ.get("ADMIN_EMAIL", "").strip().lower()
    if admin_email:
        admin_user = User.query.filter_by(email=admin_email).first()
        if admin_user and not admin_user.is_admin:
            admin_user.is_admin = True
            db.session.commit()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
