# CART3R.JAILBREAK V2 — HaloDev

Plataforma web en Flask con estética negro/rojo neón, registro e inicio de sesión, créditos virtuales, gestor de proyectos, Code Lab, Security Center, asistente local y panel administrativo.

## Requisitos
- Python 3.10+
- PostgreSQL en producción (SQLite permitido para desarrollo local)

## Ejecutar en local
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python app.py
```
Abre http://127.0.0.1:5000

## Despliegue en Railway
1. Sube el contenido de esta carpeta al directorio raíz del repositorio GitHub conectado a Railway.
2. En Railway, crea/usa un servicio PostgreSQL y una aplicación web.
3. En el servicio web configura `DATABASE_URL=${{Postgres.DATABASE_URL}}` (o la referencia con el nombre real del servicio de base de datos).
4. Configura `SECRET_KEY` con un secreto aleatorio largo y privado.
5. Configura `COOKIE_SECURE=1`.
6. Configura `ADMIN_EMAIL` con el correo que usarás para crear la cuenta administradora. Registra esa cuenta después de desplegar; si ya existe, el siguiente arranque también la promueve.
7. Publica el dominio desde Railway. El health check es `/health`.

Railway usa el comando Gunicorn definido en `railway.json`/`Procfile`. PostgreSQL se conecta mediante `DATABASE_URL`; las tablas se crean al iniciar la aplicación.

## Funciones
- Registro e inicio de sesión con hash de contraseñas, CSRF y limitación de intentos.
- Sesiones seguras, cabeceras de seguridad y endpoint `/health`.
- Dashboard personal.
- Proyectos con estados Activo, En progreso, Pausado y Completado.
- Créditos internos con historial auditable; los créditos no son dinero, no se compran ni se transfieren.
- Code Lab para guardar fragmentos (no ejecuta código).
- Security Center con recomendaciones defensivas.
- Asistente local de organización (no es un modelo de IA conectado ni ejecuta acciones externas).
- Perfil y cambio de contraseña.
- Panel `/admin` con métricas, gestión de cuentas y ajustes de créditos registrados en el ledger.

## Configuración de administrador
Define `ADMIN_EMAIL` en Railway antes de registrar la cuenta propietaria. El usuario que se registre con ese correo obtiene el rol administrador. Si la cuenta ya existe, se promueve al reiniciar la aplicación.

## Seguridad y límites
- No almacenes claves API, contraseñas ni secretos en Code Lab.
- Los fragmentos de código se almacenan como texto y nunca se ejecutan en el servidor.
- Las funciones de seguridad están destinadas a proteger sistemas propios o con autorización explícita.
- La limitación de intentos usa memoria local por defecto y un worker Gunicorn para compartirla entre hilos. Si escalas a varios workers o réplicas, configura un almacén Redis compartido con `RATELIMIT_STORAGE_URI`. Los registros de intentos de acceso guardan identidad/IP y se purgan automáticamente después de 30 días.
- La versión inicial no incluye recuperación de contraseña por correo, verificación de email ni pagos reales.
- `db.create_all()` crea tablas nuevas, pero no sustituye un sistema de migraciones cuando cambie el esquema en futuras versiones.

## Variables
| Variable | Uso |
|---|---|
| `SECRET_KEY` | Secreto de sesiones y CSRF |
| `DATABASE_URL` | URL PostgreSQL o SQLite |
| `COOKIE_SECURE` | `1` detrás de HTTPS |
| `ADMIN_EMAIL` | Correo de la cuenta administradora |
| `RATELIMIT_STORAGE_URI` | Almacén de límites; `memory://` por defecto |
| `PORT` | Puerto del servidor |

**Creador: HaloDev**
