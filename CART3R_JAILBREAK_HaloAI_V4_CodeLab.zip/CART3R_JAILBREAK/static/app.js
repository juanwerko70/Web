document.addEventListener("click", async (event) => {
  const button = event.target.closest("[data-copy]");
  if (!button) return;
  try {
    await navigator.clipboard.writeText(button.dataset.copy);
    const old = button.textContent;
    button.textContent = "Copiado ✓";
    setTimeout(() => button.textContent = old, 1400);
  } catch {
    button.textContent = "No se pudo copiar";
  }
});
document.querySelectorAll(".flash").forEach((el) => {
  setTimeout(() => { el.classList.add("fade"); }, 4500);
});


document.addEventListener("submit", (event) => {
  const message = event.target.dataset.confirm;
  if (message && !window.confirm(message)) event.preventDefault();
});

// Lightweight inline icon set; avoids emoji glyphs and external icon dependencies.
const iconPaths = {
  grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  folder:'<path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  code:'<path d="m8 8-4 4 4 4M16 8l4 4-4 4m-2-11-4 14"/>',
  spark:'<path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="m19 16 .8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/>',
  shield:'<path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11z"/><path d="m9 12 2 2 4-4"/>',
  wallet:'<rect x="3" y="5" width="18" height="15" rx="2"/><path d="M3 8h16a2 2 0 0 1 2 2v2h-5a2 2 0 0 0 0 4h5"/><path d="M16 14h.01"/>',
  'check-square':'<rect x="3" y="3" width="18" height="18" rx="2"/><path d="m7 12 3 3 7-7"/>',
  settings:'<circle cx="12" cy="12" r="3"/><path d="m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.7-.6a8 8 0 0 1-1.7 1l-.3 1.8h-2.8l-.3-1.8a8 8 0 0 1-1.7-1l-1.7.6-1.4-2.4 1.4-1.1a7 7 0 0 1 0-2l-1.4-1.1 1.4-2.4 1.7.6a8 8 0 0 1 1.7-1l.3-1.8h2.8l.3 1.8a8 8 0 0 1 1.7 1l1.7-.6 1.4 2.4-1.4 1.1a7 7 0 0 1 0 2z"/>',
  sliders:'<path d="M4 21v-7m0-4V3m8 18v-9m0-4V3m8 18v-5m0-4V3M2 14h4m4-6h4m4 8h4"/>',
  workflow:'<rect x="3" y="3" width="7" height="6" rx="1"/><rect x="14" y="15" width="7" height="6" rx="1"/><path d="M6.5 9v3a3 3 0 0 0 3 3H17M17 12l3 3-3 3"/>'
};
document.querySelectorAll('[data-icon]').forEach(el => {
  const path = iconPaths[el.dataset.icon];
  if (path) el.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true">${path}</svg>`;
});

// HALO copper particle sphere, rendered locally with canvas and no external assets.
(() => {
  const canvas = document.getElementById('halo-orb');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const points = [];
  const count = 330;
  for (let i = 0; i < count; i++) {
    const y = 1 - (i / (count - 1)) * 2;
    const radius = Math.sqrt(1 - y * y);
    const angle = Math.PI * (3 - Math.sqrt(5)) * i;
    points.push({x:Math.cos(angle)*radius, y, z:Math.sin(angle)*radius, size: i % 7 === 0 ? 2.1 : 1.25});
  }
  let rotation = 0;
  function draw() {
    const w = canvas.width, h = canvas.height, cx = w/2, cy = h/2, radius = 150;
    ctx.clearRect(0,0,w,h);
    const glow = ctx.createRadialGradient(cx,cy,10,cx,cy,160);
    glow.addColorStop(0,'rgba(198,126,83,.12)'); glow.addColorStop(1,'rgba(198,126,83,0)');
    ctx.fillStyle = glow; ctx.fillRect(0,0,w,h);
    const c = Math.cos(rotation), s = Math.sin(rotation);
    const projected = points.map(p => {
      const x = p.x*c - p.z*s, z = p.x*s + p.z*c;
      const scale = 3.2/(3.2-z*.34);
      return {x:cx+x*radius*scale,y:cy+p.y*radius*scale,z,size:p.size*scale};
    }).sort((a,b)=>a.z-b.z);
    projected.forEach(p => {
      const alpha = .34 + ((p.z+1)/2)*.62;
      ctx.beginPath(); ctx.arc(p.x,p.y,p.size,0,Math.PI*2);
      ctx.fillStyle = `rgba(231,169,132,${alpha})`;
      ctx.shadowColor = 'rgba(218,143,99,.45)'; ctx.shadowBlur = p.z > .3 ? 8 : 2; ctx.fill();
    });
    ctx.shadowBlur = 0;
    if (!reduced) rotation += .0032;
    if (!reduced) requestAnimationFrame(draw);
  }
  draw();
})();

// HALO AI chat: requests are proxied by Flask; provider secrets never reach the browser.
(() => {
  const form = document.getElementById('halo-chat-form');
  if (!form) return;
  const input = document.getElementById('halo-message');
  const messages = document.getElementById('chat-messages');
  const error = document.getElementById('chat-error');
  const send = document.getElementById('send-message');
  const csrf = document.getElementById('csrf-token').value;
  const list = document.getElementById('conversation-list');
  let conversationId = null;
  const esc = (value) => String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  function addMessage(role, content) {
    const row = document.createElement('div');
    row.className = `chat-message ${role === 'assistant' ? 'from-halo' : 'from-user'}`;
    const who = document.createElement('small'); who.textContent = role === 'assistant' ? 'HALO' : 'TÚ';
    const body = document.createElement('div'); body.className = 'chat-message-content';
    body.innerHTML = esc(content).replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>').replace(/\n/g, '<br>');
    row.append(who, body); messages.append(row); messages.scrollTop = messages.scrollHeight;
  }
  function welcome() {
    messages.innerHTML = '<div class="chat-welcome"><div class="welcome-mark">H</div><h2>¿Qué vamos a construir?</h2><p>Pregunta, analiza una idea, solicita ayuda con código o planifica un proyecto.</p><div class="prompt-suggestions"><button type="button" data-prompt="Ayúdame a planificar una aplicación web completa.">Planificar una aplicación</button><button type="button" data-prompt="Explícame cómo mejorar la seguridad de mi proyecto web.">Revisar seguridad</button><button type="button" data-prompt="Escribe un ejemplo de API Flask bien estructurada y explícamela.">Crear código</button></div></div>';
  }
  async function loadConversation(id) {
    const response = await fetch(`/api/assistant/history/${id}`);
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'No se pudo cargar el historial.');
    conversationId = id; messages.innerHTML = '';
    data.messages.forEach(m => addMessage(m.role, m.content));
    list.querySelectorAll('.history-item').forEach(el => el.classList.toggle('active', el.dataset.conversation === String(id)));
  }
  list?.addEventListener('click', async (event) => {
    const item = event.target.closest('[data-conversation]'); if (!item) return;
    try { await loadConversation(item.dataset.conversation); } catch (e) { error.textContent = e.message; }
  });
  document.getElementById('new-chat')?.addEventListener('click', () => { conversationId = null; welcome(); error.textContent = ''; list.querySelectorAll('.history-item').forEach(el => el.classList.remove('active')); input.focus(); });
  messages.addEventListener('click', (event) => { const btn = event.target.closest('[data-prompt]'); if (btn) { input.value = btn.dataset.prompt; input.focus(); } });
  form.addEventListener('submit', async (event) => {
    event.preventDefault(); const message = input.value.trim(); if (!message || send.disabled) return;
    error.textContent = ''; addMessage('user', message); input.value = ''; send.disabled = true; send.textContent = 'Conectando...';
    const pending = document.createElement('div'); pending.className = 'chat-pending'; pending.textContent = 'HALO está pensando...'; messages.append(pending); messages.scrollTop = messages.scrollHeight;
    try {
      const response = await fetch('/api/assistant/chat', {method:'POST', headers:{'Content-Type':'application/json','X-CSRFToken':csrf}, body:JSON.stringify({message, conversation_id:conversationId})});
      const data = await response.json(); pending.remove();
      if (!response.ok) throw new Error(data.error || 'No se pudo completar la consulta.');
      conversationId = data.conversation_id; addMessage('assistant', data.answer);
      document.getElementById('chat-credits').textContent = `${data.credits} CR`;
      if (!list.querySelector(`[data-conversation="${conversationId}"]`)) {
        const item = document.createElement('button'); item.className = 'history-item active'; item.dataset.conversation = conversationId; item.textContent = message.slice(0, 90); list.prepend(item);
        const empty = list.querySelector('.empty-history'); if (empty) empty.remove();
      }
      list.querySelectorAll('.history-item').forEach(el => el.classList.toggle('active', el.dataset.conversation === String(conversationId)));
    } catch (e) { pending.remove(); error.textContent = e.message; addMessage('assistant', `No pude completar la consulta: ${e.message}`); }
    finally { send.disabled = false; send.textContent = 'Enviar ↗'; input.focus(); }
  });
})();

// Code Lab project generation and owner-authorized project modification.
(() => {
  const build = document.getElementById('build-form');
  if (!build) return;
  const csrf = document.getElementById('code-csrf').value;
  const error = document.getElementById('lab-error');
  const output = document.getElementById('lab-output');
  const filesBox = document.getElementById('output-files');
  const esc = (v) => String(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function showError(message) { error.textContent = message; error.style.display = 'block'; }
  function showFiles(files, notes, title) {
    output.style.display = 'block'; document.getElementById('output-title').textContent = title;
    document.getElementById('output-count').textContent = `${files.length} ARCHIVOS`;
    document.getElementById('output-notes').textContent = notes || 'Archivos generados. Revisa el contenido antes de desplegar.';
    filesBox.innerHTML = '';
    files.forEach(file => {
      const card = document.createElement('article'); card.className = 'lab-file';
      const head = document.createElement('div'); head.className = 'lab-file-head';
      const name = document.createElement('b'); name.textContent = file.path;
      const download = document.createElement('button'); download.type = 'button'; download.className = 'copy-btn'; download.textContent = 'Descargar';
      download.addEventListener('click', () => { const blob = new Blob([file.content], {type:'text/plain;charset=utf-8'}); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href=url; a.download=file.path.split('/').pop() || 'source.txt'; a.click(); URL.revokeObjectURL(url); });
      head.append(name, download); const pre = document.createElement('pre'); const code = document.createElement('code'); code.textContent = file.content; pre.append(code); card.append(head,pre); filesBox.append(card);
    });
    output.scrollIntoView({behavior:'smooth',block:'start'});
  }
  async function post(url, body, button, busy) {
    error.style.display='none'; button.disabled=true; const old=button.textContent; button.textContent=busy;
    try { const res=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','X-CSRFToken':csrf},body:JSON.stringify(body)}); const data=await res.json(); if(!res.ok) throw new Error(data.error || 'La operación no se pudo completar.'); document.getElementById('chat-credits')?.replaceChildren(document.createTextNode(`${data.credits} CR`)); return data; }
    catch(e){showError(e.message);return null;} finally {button.disabled=false;button.textContent=old;}
  }
  build.addEventListener('submit', async e => { e.preventDefault(); const button=document.getElementById('build-submit'); const data=await post('/api/code-lab/build',{name:document.getElementById('build-name').value,description:document.getElementById('build-description').value,stack:document.getElementById('build-stack').value},button,'Generando archivos...'); if(data){const select=document.getElementById('modify-project');const opt=document.createElement('option');opt.value=data.project_id;opt.textContent=data.name;select.prepend(opt);select.value=data.project_id;showFiles(data.files,data.notes,`Proyecto: ${data.name}`);} });
  document.getElementById('modify-form').addEventListener('submit', async e => { e.preventDefault(); const id=document.getElementById('modify-project').value; if(!id){showError('Selecciona un proyecto primero.');return;} const button=document.getElementById('modify-submit'); const data=await post(`/api/code-lab/projects/${id}/modify`,{instruction:document.getElementById('modify-instruction').value},button,'Modificando proyecto...'); if(data) showFiles(data.files,data.notes,'Proyecto actualizado'); });
})();
