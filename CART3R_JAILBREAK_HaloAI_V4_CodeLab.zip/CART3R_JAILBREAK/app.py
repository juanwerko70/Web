import os
import re
import secrets
from datetime import datetime, timedelta
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, abort
from flask_sqlalchemy import SQLAlchemy
from flask_wtf.csrf import CSRFProtect
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import or_, func, text
from sqlalchemy.exc import IntegrityError
import json
import urllib.request
import urllib.error
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address


def normalize_database_url(url: str) -> str:
    if url.startswith("postgres://"):
        return url.replace("postgres://", "postgresql+psycopg://", 1)
    if url.startswith("postgresql://"):
        return url.replace("postgresql://", "postgresql+psycopg://", 1)
    return url


app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("SECRET_KEY") or secrets.token_urlsafe(48),
    SQLALCHEMY_DATABASE_URI=normalize_database_url(os.environ.get("DATABASE_URL", "sqlite:///cart3r.db")),
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    SQLALCHEMY_ENGINE_OPTIONS={"pool_pre_ping": True},
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "1" if os.environ.get("RAILWAY_ENVIRONMENT_NAME") else "0") == "1",
    PERMANENT_SESSION_LIFETIME=timedelta(days=7),
    MAX_CONTENT_LENGTH=2 * 1024 * 1024,
)

db = SQLAlchemy(app)
CSRFProtect(app)
limiter = Limiter(get_remote_address, app=app, default_limits=[], storage_uri=os.environ.get("RATELIMIT_STORAGE_URI", "memory://"))


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(32), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    credits = db.Column(db.Integer, default=100, nullable=False)
    is_admin = db.Column(db.Boolean, default=False, nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


class Project(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"), nullable=False, index=True)
    name = db.Column(db.String(80), nullable=False)
    description = db.Column(db.String(300), default="")
    status = db.Column(db.String(20), default="Activo", nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


class ProjectFile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey("project.id", ondelete="CASCADE"), nullable=False, index=True)
    path = db.Column(db.String(240), nullable=False)
    content = db.Column(db.Text, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    __table_args__ = (db.UniqueConstraint("project_id", "path", name="uq_project_file_path"),)


class CreditEvent(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"), nullable=False, index=True)
    amount = db.Column(db.Integer, nullable=False)
    reason = db.Column(db.String(120), nullable=False)
    actor_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


class SavedSnippet(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"), nullable=False, index=True)
    title = db.Column(db.String(80), nullable=False)
    language = db.Column(db.String(20), default="python")
    code = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


class Task(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"), nullable=False, index=True)
    title = db.Column(db.String(140), nullable=False)
    priority = db.Column(db.String(12), default="Media", nullable=False)
    status = db.Column(db.String(16), default="Pendiente", nullable=False)
    due_date = db.Column(db.Date, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


class AIConversation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"), nullable=False, index=True)
    title = db.Column(db.String(100), nullable=False, default="Nueva conversación")
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)


class AIMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    conversation_id = db.Column(db.Integer, db.ForeignKey("ai_conversation.id", ondelete="CASCADE"), nullable=False, index=True)
    role = db.Column(db.String(12), nullable=False)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


class LoginAttempt(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    identity = db.Column(db.String(120), nullable=False, index=True)
    ip_address = db.Column(db.String(64), nullable=False, index=True)
    succeeded = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


def current_user():
    uid = session.get("user_id")
    user = db.session.get(User, uid) if uid else None
    if user and not user.is_active:
        session.clear()
        return None
    return user


@app.context_processor
def inject_user():
    return {"current_user": current_user()}


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            flash("Inicia sesión para continuar.", "warning")
            return redirect(url_for("login", next=request.path))
        return fn(*args, **kwargs)
    return wrapper


def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapper(*args, **kwargs):
        if not current_user().is_admin:
            abort(403)
        return fn(*args, **kwargs)
    return wrapper


def record_credit(user_id, amount, reason, actor_id=None):
    user = db.session.get(User, user_id)
    if not user:
        raise ValueError("Usuario no encontrado")
    if user.credits + amount < 0:
        raise ValueError("El saldo no puede quedar negativo")
    user.credits += amount
    db.session.add(CreditEvent(user_id=user.id, amount=amount, reason=reason[:120], actor_id=actor_id))


@app.after_request
def security_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    response.headers.setdefault("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; script-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'")
    if request.is_secure or app.config["SESSION_COOKIE_SECURE"]:
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    return response


@app.get("/health")
def health():
    try:
        db.session.execute(text("SELECT 1"))
        return jsonify(status="ok", app="CART3R.JAILBREAK", version="2.0.0"), 200
    except Exception:
        app.logger.exception("Health check database failure")
        return jsonify(status="degraded"), 503


@app.route("/")
def index():
    if current_user():
        return redirect(url_for("dashboard"))
    return render_template("landing.html")


@app.route("/register", methods=["GET", "POST"])
@limiter.limit("5 per hour", methods=["POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not re.fullmatch(r"[A-Za-z0-9_]{3,32}", username):
            flash("El usuario debe tener 3–32 caracteres: letras, números o guion bajo.", "error")
        elif not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            flash("Introduce un correo válido.", "error")
        elif len(password) < 10 or len(password) > 128:
            flash("La contraseña debe tener entre 10 y 128 caracteres.", "error")
        elif User.query.filter(or_(User.username.ilike(username), User.email == email)).first():
            flash("Ese usuario o correo ya está registrado.", "error")
        else:
            admin_email = os.environ.get("ADMIN_EMAIL", "").strip().lower()
            user = User(username=username, email=email, password_hash=generate_password_hash(password), credits=100, is_admin=bool(admin_email and email == admin_email))
            db.session.add(user)
            db.session.flush()
            db.session.add(CreditEvent(user_id=user.id, amount=100, reason="Bono de bienvenida"))
            db.session.commit()
            session.clear()
            session.permanent = True
            session["user_id"] = user.id
            flash("Cuenta creada. Recibiste 100 créditos de bienvenida.", "success")
            return redirect(url_for("dashboard"))
    return render_template("auth.html", mode="register")


@app.route("/login", methods=["GET", "POST"])
@limiter.limit("10 per 15 minutes", methods=["POST"])
def login():
    if request.method == "POST":
        identity = request.form.get("identity", "").strip()
        user = User.query.filter(or_(User.username.ilike(identity), User.email == identity.lower())).first()
        valid = bool(user and user.is_active and check_password_hash(user.password_hash, request.form.get("password", "")))
        db.session.add(LoginAttempt(identity=identity[:120], ip_address=get_remote_address()[:64], succeeded=valid))
        db.session.commit()
        if valid:
            session.clear()
            session.permanent = True
            session["user_id"] = user.id
            flash("Sesión iniciada correctamente.", "success")
            target = request.args.get("next", "")
            if target.startswith("/") and not target.startswith("//"):
                return redirect(target)
            return redirect(url_for("dashboard"))
        flash("Credenciales incorrectas o cuenta desactivada.", "error")
    return render_template("auth.html", mode="login")


@app.post("/logout")
@login_required
def logout():
    session.clear()
    flash("Has cerrado sesión.", "success")
    return redirect(url_for("index"))


@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    projects = Project.query.filter_by(user_id=user.id).order_by(Project.created_at.desc()).limit(5).all()
    events = CreditEvent.query.filter_by(user_id=user.id).order_by(CreditEvent.created_at.desc()).limit(6).all()
    snippets_count = SavedSnippet.query.filter_by(user_id=user.id).count()
    tasks_count = Task.query.filter_by(user_id=user.id, status="Pendiente").count()
    return render_template("dashboard.html", projects=projects, events=events, snippets_count=snippets_count, tasks_count=tasks_count)


@app.route("/projects", methods=["GET", "POST"])
@login_required
def projects():
    user = current_user()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        desc = request.form.get("description", "").strip()
        if not name or len(name) > 80 or len(desc) > 300:
            flash("Revisa el nombre y la descripción del proyecto.", "error")
        else:
            db.session.add(Project(user_id=user.id, name=name, description=desc))
            db.session.commit()
            flash("Proyecto creado.", "success")
        return redirect(url_for("projects"))
    items = Project.query.filter_by(user_id=user.id).order_by(Project.created_at.desc()).all()
    return render_template("projects.html", projects=items)


@app.post("/projects/<int:project_id>/delete")
@login_required
def delete_project(project_id):
    item = Project.query.filter_by(id=project_id, user_id=current_user().id).first_or_404()
    db.session.delete(item)
    db.session.commit()
    flash("Proyecto eliminado.", "success")
    return redirect(url_for("projects"))


@app.post("/projects/<int:project_id>/status")
@login_required
def update_project_status(project_id):
    item = Project.query.filter_by(id=project_id, user_id=current_user().id).first_or_404()
    status = request.form.get("status", "")
    if status not in {"Activo", "En progreso", "Pausado", "Completado"}:
        abort(400)
    item.status = status
    db.session.commit()
    flash("Estado del proyecto actualizado.", "success")
    return redirect(url_for("projects"))


@app.route("/credits")
@login_required
def credits():
    user = current_user()
    events = CreditEvent.query.filter_by(user_id=user.id).order_by(CreditEvent.created_at.desc()).all()
    return render_template("credits.html", events=events)


@app.route("/code-lab", methods=["GET", "POST"])
@login_required
def code_lab():
    user = current_user()
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        language = request.form.get("language", "python")
        code = request.form.get("code", "")
        allowed_languages = {"python", "javascript", "html", "css", "sql", "bash", "otro"}
        if title and len(title) <= 80 and code and len(code) <= 20000 and language in allowed_languages:
            db.session.add(SavedSnippet(user_id=user.id, title=title, language=language, code=code))
            db.session.commit()
            flash("Fragmento guardado.", "success")
        else:
            flash("Revisa el título, lenguaje y longitud del código.", "error")
        return redirect(url_for("code_lab"))
    snippets = SavedSnippet.query.filter_by(user_id=user.id).order_by(SavedSnippet.created_at.desc()).all()
    projects = Project.query.filter_by(user_id=user.id).order_by(Project.created_at.desc()).all()
    return render_template("code_lab.html", snippets=snippets, projects=projects)


@app.post("/api/code-lab/build")
@login_required
@limiter.limit("5 per minute")
def code_lab_build():
    user = current_user()
    api_key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not api_key:
        return jsonify(error="HALO AI no está conectada. Configura OPENAI_API_KEY en Railway → Variables."), 503
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()[:80]
    description = str(data.get("description", "")).strip()
    stack = str(data.get("stack", "")).strip()
    if not name or not description or len(description) > 3000 or stack not in {"html-css-js", "react-vite", "nextjs", "python-flask", "python-fastapi", "node-express"}:
        return jsonify(error="Completa el nombre, una descripción válida y selecciona una tecnología."), 400
    cost = 5
    if user.credits < cost:
        return jsonify(error="Necesitas al menos 5 créditos para generar un proyecto."), 402
    stack_names = {"html-css-js":"HTML, CSS y JavaScript sin framework", "react-vite":"React + Vite + JavaScript", "nextjs":"Next.js + TypeScript", "python-flask":"Python + Flask", "python-fastapi":"Python + FastAPI", "node-express":"Node.js + Express"}
    system = "Eres un generador profesional de proyectos de software. Devuelve exclusivamente JSON válido con esta forma: {\"files\":[{\"path\":\"ruta/archivo.ext\",\"content\":\"contenido completo\"}],\"notes\":\"instrucciones breves\"}. Genera una base funcional, segura y ejecutable. No incluyas secretos, credenciales ni acciones destructivas. Máximo 12 archivos y 45000 caracteres totales. Incluye README y archivos de dependencias/arranque apropiados."
    prompt = f"Crea el proyecto {name}. Descripción: {description}. Stack elegido: {stack_names[stack]}. Produce archivos completos y coherentes, con estructura mantenible."
    try:
        answer = _halo_completion(api_key, system, prompt, 5000)
        result = json.loads(answer)
        files = result.get("files", [])
        if not isinstance(files, list) or not files or len(files) > 12:
            raise ValueError("Formato de archivos inválido")
        clean = []
        total = 0
        for item in files:
            path = str(item.get("path", "")).replace('\\', '/')
            content = str(item.get("content", ""))
            if not path or path.startswith('/') or '..' in path.split('/') or len(path) > 240 or not content:
                continue
            total += len(content)
            clean.append((path, content))
        if not clean or total > 45000:
            raise ValueError("Proyecto fuera de los límites permitidos")
        project = Project(user_id=user.id, name=name, description=description)
        db.session.add(project); db.session.flush()
        for path, content in clean:
            db.session.add(ProjectFile(project_id=project.id, path=path, content=content))
        record_credit(user.id, -cost, "Generación de proyecto Code Lab")
        db.session.commit()
        return jsonify(project_id=project.id, name=project.name, files=[{"path":x,"content":y} for x,y in clean], notes=str(result.get("notes", ""))[:2000], credits=user.credits)
    except (ValueError, KeyError, TypeError, json.JSONDecodeError):
        db.session.rollback(); app.logger.exception("Invalid Code Lab generation response")
        return jsonify(error="HALO recibió una respuesta de proyecto inválida. Inténtalo de nuevo."), 502
    except Exception:
        db.session.rollback(); app.logger.exception("Code Lab generation failed")
        return jsonify(error="No se pudo generar el proyecto. Revisa la conexión y la cuota del proveedor."), 502


@app.get("/api/code-lab/projects/<int:project_id>")
@login_required
def code_lab_project(project_id):
    project = Project.query.filter_by(id=project_id, user_id=current_user().id).first_or_404()
    files = ProjectFile.query.filter_by(project_id=project.id).order_by(ProjectFile.path.asc()).all()
    return jsonify(project={"id":project.id,"name":project.name,"description":project.description}, files=[{"path":f.path,"content":f.content} for f in files])


@app.post("/api/code-lab/projects/<int:project_id>/modify")
@login_required
@limiter.limit("5 per minute")
def code_lab_modify(project_id):
    user = current_user()
    project = Project.query.filter_by(id=project_id, user_id=user.id).first_or_404()
    api_key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not api_key:
        return jsonify(error="HALO AI no está conectada. Configura OPENAI_API_KEY en Railway."), 503
    data = request.get_json(silent=True) or {}
    instruction = str(data.get("instruction", "")).strip()
    if not instruction or len(instruction) > 3000:
        return jsonify(error="Escribe una instrucción de hasta 3.000 caracteres."), 400
    cost = 3
    if user.credits < cost:
        return jsonify(error="Necesitas al menos 3 créditos para modificar este proyecto."), 402
    files = ProjectFile.query.filter_by(project_id=project.id).order_by(ProjectFile.path.asc()).all()
    if not files:
        return jsonify(error="Este proyecto todavía no tiene archivos generados en Code Lab."), 400
    snapshot = json.dumps([{"path":f.path,"content":f.content} for f in files], ensure_ascii=False)
    if len(snapshot) > 42000:
        return jsonify(error="El proyecto es demasiado grande para modificarlo en una sola operación."), 413
    system = "Eres un ingeniero de software que modifica únicamente el proyecto proporcionado por su propietario. Devuelve exclusivamente JSON válido: {\"files\":[{\"path\":\"...\",\"content\":\"...\"}],\"notes\":\"...\"}. Devuelve el conjunto completo de archivos actualizado, máximo 12 archivos y 45000 caracteres. No agregues código malicioso, robo de datos, persistencia oculta ni acceso no autorizado. Conserva lo que no se pidió cambiar."
    prompt = "INSTRUCCIÓN DEL PROPIETARIO:\n" + instruction + "\n\nARCHIVOS ACTUALES:\n" + snapshot
    try:
        result = json.loads(_halo_completion(api_key, system, prompt, 6000))
        new_files = result.get("files", [])
        if not isinstance(new_files, list) or not new_files or len(new_files) > 12:
            raise ValueError("Formato inválido")
        normalized = {}
        total = 0
        for item in new_files:
            path = str(item.get("path", "")).replace('\\', '/')
            content = str(item.get("content", ""))
            if not path or path.startswith('/') or '..' in path.split('/') or len(path) > 240 or not content:
                continue
            normalized[path] = content; total += len(content)
        if not normalized or total > 45000:
            raise ValueError("Límites excedidos")
        ProjectFile.query.filter_by(project_id=project.id).delete()
        for path, content in normalized.items(): db.session.add(ProjectFile(project_id=project.id, path=path, content=content))
        record_credit(user.id, -cost, "Modificación de proyecto con HALO")
        db.session.commit()
        return jsonify(files=[{"path":k,"content":v} for k,v in normalized.items()], notes=str(result.get("notes", ""))[:2000], credits=user.credits)
    except Exception:
        db.session.rollback(); app.logger.exception("Code Lab project modification failed")
        return jsonify(error="No se pudo aplicar el cambio. El proyecto original se conservó."), 502


def _halo_completion(api_key, system, prompt, max_tokens):
    payload = json.dumps({"model": os.environ.get("OPENAI_MODEL", "gpt-4.1-mini"), "messages":[{"role":"system","content":system},{"role":"user","content":prompt}], "temperature":0.2, "max_tokens":max_tokens}).encode("utf-8")
    req = urllib.request.Request("https://api.openai.com/v1/chat/completions", data=payload, headers={"Authorization":"Bearer "+api_key,"Content-Type":"application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=90) as response:
        data = json.loads(response.read().decode("utf-8"))
    return data["choices"][0]["message"]["content"].strip()


@app.post("/snippets/<int:snippet_id>/delete")
@login_required
def delete_snippet(snippet_id):
    item = SavedSnippet.query.filter_by(id=snippet_id, user_id=current_user().id).first_or_404()
    db.session.delete(item)
    db.session.commit()
    flash("Fragmento eliminado.", "success")
    return redirect(url_for("code_lab"))


@app.route("/security")
@login_required
def security():
    return render_template("security.html")


@app.route("/tasks", methods=["GET", "POST"])
@login_required
def tasks():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        priority = request.form.get("priority", "Media")
        due_raw = request.form.get("due_date", "").strip()
        if not title or len(title) > 140 or priority not in {"Baja", "Media", "Alta"}:
            flash("Revisa el título y la prioridad de la tarea.", "error")
        else:
            due = None
            if due_raw:
                try:
                    due = datetime.strptime(due_raw, "%Y-%m-%d").date()
                except ValueError:
                    flash("La fecha no es válida.", "error")
                    return redirect(url_for("tasks"))
            db.session.add(Task(user_id=current_user().id, title=title, priority=priority, due_date=due))
            db.session.commit()
            flash("Tarea creada.", "success")
        return redirect(url_for("tasks"))
    items = Task.query.filter_by(user_id=current_user().id).order_by(Task.status.asc(), Task.created_at.desc()).all()
    return render_template("tasks.html", tasks=items)


@app.post("/tasks/<int:task_id>/toggle")
@login_required
def toggle_task(task_id):
    item = Task.query.filter_by(id=task_id, user_id=current_user().id).first_or_404()
    item.status = "Completada" if item.status == "Pendiente" else "Pendiente"
    db.session.commit()
    flash("Estado de tarea actualizado.", "success")
    return redirect(url_for("tasks"))


@app.post("/tasks/<int:task_id>/delete")
@login_required
def delete_task(task_id):
    item = Task.query.filter_by(id=task_id, user_id=current_user().id).first_or_404()
    db.session.delete(item)
    db.session.commit()
    flash("Tarea eliminada.", "success")
    return redirect(url_for("tasks"))


@app.route("/assistant")
@login_required
def assistant():
    conversations = AIConversation.query.filter_by(user_id=current_user().id).order_by(AIConversation.updated_at.desc()).limit(30).all()
    configured = bool(os.environ.get("OPENAI_API_KEY", "").strip())
    return render_template("assistant.html", conversations=conversations, ai_configured=configured)


@app.get("/api/assistant/history/<int:conversation_id>")
@login_required
def assistant_history(conversation_id):
    conversation = AIConversation.query.filter_by(id=conversation_id, user_id=current_user().id).first_or_404()
    messages = AIMessage.query.filter_by(conversation_id=conversation.id).order_by(AIMessage.id.asc()).limit(100).all()
    return jsonify(conversation={"id": conversation.id, "title": conversation.title}, messages=[{"role": m.role, "content": m.content} for m in messages])


@app.post("/api/assistant/chat")
@login_required
@limiter.limit("12 per minute")
def assistant_chat():
    user = current_user()
    api_key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not api_key:
        return jsonify(error="HALO AI todavía no está configurada. El administrador debe añadir OPENAI_API_KEY en las variables privadas de Railway."), 503
    try:
        cost = max(1, min(100, int(os.environ.get("AI_CREDITS_PER_MESSAGE", "2"))))
    except ValueError:
        cost = 2
    if user.credits < cost:
        return jsonify(error="No tienes créditos suficientes para esta consulta."), 402
    data = request.get_json(silent=True) or {}
    prompt = str(data.get("message", "")).strip()
    if not prompt or len(prompt) > 6000:
        return jsonify(error="Escribe un mensaje de hasta 6.000 caracteres."), 400
    conversation_id = data.get("conversation_id")
    conversation = None
    if conversation_id:
        try:
            conversation = AIConversation.query.filter_by(id=int(conversation_id), user_id=user.id).first()
        except (TypeError, ValueError):
            conversation = None
        if not conversation:
            return jsonify(error="La conversación no existe."), 404
    else:
        conversation = AIConversation(user_id=user.id, title=prompt[:90])
        db.session.add(conversation)
        db.session.flush()

    prior = AIMessage.query.filter_by(conversation_id=conversation.id).order_by(AIMessage.id.desc()).limit(12).all()
    prior.reverse()
    messages = [{"role": "system", "content": "Eres HALO, el asistente de CART3R.JAILBREAK creado por HaloDev. Responde en el idioma del usuario, normalmente español. Sé claro, preciso y útil. Para código, explica los cambios y advierte sobre riesgos. No afirmes que ejecutaste acciones que no realizaste. Rechaza instrucciones peligrosas o ilegales y ofrece alternativas seguras."}]
    messages.extend({"role": m.role, "content": m.content} for m in prior)
    messages.append({"role": "user", "content": prompt})
    payload = json.dumps({"model": os.environ.get("OPENAI_MODEL", "gpt-4.1-mini"), "messages": messages, "temperature": 0.7, "max_tokens": 1800}).encode("utf-8")
    req = urllib.request.Request("https://api.openai.com/v1/chat/completions", data=payload, headers={"Authorization": "Bearer " + api_key, "Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=45) as response:
            result = json.loads(response.read().decode("utf-8"))
        answer = result["choices"][0]["message"]["content"].strip()
        if not answer:
            raise ValueError("Respuesta vacía del proveedor")
    except urllib.error.HTTPError as exc:
        app.logger.warning("AI provider returned HTTP %s", exc.code)
        if exc.code == 401:
            return jsonify(error="La clave de IA configurada no es válida. Revisa OPENAI_API_KEY en Railway."), 502
        if exc.code == 429:
            return jsonify(error="El proveedor de IA alcanzó su límite o cuota. Revisa el uso y la facturación de la API."), 502
        return jsonify(error="El proveedor de IA no pudo procesar la solicitud. Inténtalo más tarde."), 502
    except (urllib.error.URLError, TimeoutError, ValueError, KeyError, IndexError, json.JSONDecodeError):
        app.logger.exception("AI provider request failed")
        return jsonify(error="No fue posible conectar con el proveedor de IA. Inténtalo de nuevo."), 502

    record_credit(user.id, -cost, "Consulta HALO AI")
    db.session.add(AIMessage(conversation_id=conversation.id, role="user", content=prompt))
    db.session.add(AIMessage(conversation_id=conversation.id, role="assistant", content=answer))
    conversation.updated_at = datetime.utcnow()
    db.session.commit()
    return jsonify(conversation_id=conversation.id, answer=answer, credits=user.credits, charged=cost)


@app.route("/settings", methods=["GET", "POST"])
@login_required
def settings():
    user = current_user()
    if request.method == "POST":
        action = request.form.get("action")
        if action == "profile":
            username = request.form.get("username", "").strip()
            email = request.form.get("email", "").strip().lower()
            if not re.fullmatch(r"[A-Za-z0-9_]{3,32}", username) or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
                flash("Revisa el usuario y el correo.", "error")
            elif User.query.filter(User.id != user.id, or_(User.username.ilike(username), User.email == email)).first():
                flash("Ese usuario o correo ya está en uso.", "error")
            else:
                user.username, user.email = username, email
                if email == os.environ.get("ADMIN_EMAIL", "").strip().lower():
                    user.is_admin = True
                db.session.commit()
                flash("Perfil actualizado.", "success")
        elif action == "password":
            old_password = request.form.get("old_password", "")
            new_password = request.form.get("new_password", "")
            if not check_password_hash(user.password_hash, old_password):
                flash("La contraseña actual no coincide.", "error")
            elif len(new_password) < 10 or len(new_password) > 128:
                flash("La nueva contraseña debe tener entre 10 y 128 caracteres.", "error")
            else:
                user.password_hash = generate_password_hash(new_password)
                db.session.commit()
                flash("Contraseña actualizada.", "success")
        return redirect(url_for("settings"))
    return render_template("settings.html")


@app.route("/admin")
@admin_required
def admin_dashboard():
    stats = {
        "users": User.query.count(),
        "active_users": User.query.filter_by(is_active=True).count(),
        "projects": Project.query.count(),
        "snippets": SavedSnippet.query.count(),
        "tasks": Task.query.count(),
        "credits": db.session.query(func.coalesce(func.sum(User.credits), 0)).scalar(),
        "failed_logins": LoginAttempt.query.filter_by(succeeded=False).filter(LoginAttempt.created_at >= datetime.utcnow() - timedelta(hours=24)).count(),
    }
    users = User.query.order_by(User.created_at.desc()).limit(12).all()
    return render_template("admin.html", stats=stats, users=users)


@app.post("/admin/users/<int:user_id>/credits")
@admin_required
def admin_adjust_credits(user_id):
    target = User.query.get_or_404(user_id)
    try:
        amount = int(request.form.get("amount", "0"))
        reason = request.form.get("reason", "Ajuste administrativo").strip()
        if amount == 0 or abs(amount) > 10000 or not reason:
            raise ValueError("Usa un ajuste entre -10.000 y 10.000 y escribe un motivo")
        record_credit(target.id, amount, "Admin: " + reason, actor_id=current_user().id)
        db.session.commit()
        flash("Saldo actualizado y movimiento registrado.", "success")
    except (ValueError, TypeError) as exc:
        db.session.rollback()
        flash(str(exc), "error")
    return redirect(url_for("admin_dashboard"))


@app.post("/admin/users/<int:user_id>/status")
@admin_required
def admin_toggle_user(user_id):
    target = User.query.get_or_404(user_id)
    if target.id == current_user().id:
        flash("No puedes desactivar tu propia cuenta.", "error")
    else:
        target.is_active = not target.is_active
        db.session.commit()
        flash("Estado de cuenta actualizado.", "success")
    return redirect(url_for("admin_dashboard"))


@app.errorhandler(403)
def forbidden(_):
    return render_template("error.html", code=403, message="No tienes permisos para acceder a esta sección."), 403


@app.errorhandler(404)
def not_found(_):
    return render_template("error.html", code=404, message="No encontramos esa página."), 404


@app.errorhandler(429)
def too_many_requests(_):
    return render_template("error.html", code=429, message="Demasiados intentos. Espera un momento y vuelve a intentarlo."), 429


@app.errorhandler(500)
def server_error(_):
    db.session.rollback()
    app.logger.exception("Unhandled server error")
    return render_template("error.html", code=500, message="Ocurrió un error interno."), 500


with app.app_context():
    db.create_all()
    LoginAttempt.query.filter(LoginAttempt.created_at < datetime.utcnow() - timedelta(days=30)).delete(synchronize_session=False)
    db.session.commit()
    admin_email = os.environ.get("ADMIN_EMAIL", "").strip().lower()
    if admin_email:
        admin_user = User.query.filter_by(email=admin_email).first()
        if admin_user and not admin_user.is_admin:
            admin_user.is_admin = True
            db.session.commit()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
