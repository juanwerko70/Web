document.addEventListener("click", async (event) => {
  const button = event.target.closest("[data-copy]");
  if (!button) return;
  try {
    await navigator.clipboard.writeText(button.dataset.copy);
    const old = button.textContent;
    button.textContent = "Copiado ✓";
    setTimeout(() => button.textContent = old, 1400);
  } catch {
    button.textContent = "No se pudo copiar";
  }
});
document.querySelectorAll(".flash").forEach((el) => {
  setTimeout(() => { el.classList.add("fade"); }, 4500);
});
