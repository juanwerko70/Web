# CART3R.JAILBREAK — HaloDev

Plataforma web personal con estética negro/rojo neón, autenticación, créditos virtuales, proyectos, Code Lab, centro de seguridad y asistente local.

## Requisitos
- Python 3.10+
- pip

## Ejecutar en local
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python app.py
```
Abre http://127.0.0.1:5000

La base SQLite `cart3r.db` se crea automáticamente. Cada cuenta nueva recibe 100 créditos de bienvenida. En esta versión los créditos son puntos internos sin valor monetario, no transferibles y no canjeables.

## Módulos
- Dashboard con resumen de cuenta, proyectos y actividad.
- Registro e inicio de sesión con contraseñas hasheadas.
- Créditos y movimientos.
- Gestor de proyectos.
- Code Lab para guardar fragmentos (no ejecuta código).
- Security Center con checklist defensivo.
- Asistente local de organización (sin conexión a servicios externos).
- Ajustes de cuenta.

## Antes de publicar
1. Define `SECRET_KEY` con un valor aleatorio largo y privado.
2. Configura HTTPS y `COOKIE_SECURE=1`.
3. Usa PostgreSQL u otra base de datos gestionada para producción.
4. Ejecuta detrás de un servidor WSGI de producción; no uses el servidor de desarrollo de Flask.
5. Añade límites de intentos de login, verificación de correo, recuperación de contraseña y monitorización.
6. Revisa privacidad, retención y eliminación de datos. No guardes secretos ni claves API en fragmentos.
7. Los créditos son demostrativos; no representan dinero ni compras reales.

## Seguridad y uso responsable
El Code Lab almacena texto y no ejecuta código. El Security Center está orientado a protección de cuentas y sistemas propios o autorizados. No incluye automatización de reportes, acceso no autorizado, evasión de controles ni acciones sobre cuentas de terceros.
