import os, re, secrets
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, abort
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_wtf.csrf import CSRFProtect

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-change-this-secret-before-deploying")
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///cart3r.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("COOKIE_SECURE", "0") == "1"
db = SQLAlchemy(app)
CSRFProtect(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(32), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    credits = db.Column(db.Integer, default=100, nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Project(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    name = db.Column(db.String(80), nullable=False)
    description = db.Column(db.String(300), default="")
    status = db.Column(db.String(20), default="Activo")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class CreditEvent(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    amount = db.Column(db.Integer, nullable=False)
    reason = db.Column(db.String(120), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class SavedSnippet(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    title = db.Column(db.String(80), nullable=False)
    language = db.Column(db.String(20), default="python")
    code = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

def current_user():
    uid = session.get("user_id")
    return db.session.get(User, uid) if uid else None

@app.context_processor
def inject_user():
    return {"current_user": current_user()}

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            flash("Inicia sesión para continuar.", "warning")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

@app.route("/")
def index():
    if current_user():
        return redirect(url_for("dashboard"))
    return render_template("landing.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not re.fullmatch(r"[A-Za-z0-9_]{3,32}", username):
            flash("El usuario debe tener 3–32 caracteres: letras, números o guion bajo.", "error")
        elif not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            flash("Introduce un correo válido.", "error")
        elif len(password) < 10:
            flash("La contraseña debe tener al menos 10 caracteres.", "error")
        elif User.query.filter((User.username == username) | (User.email == email)).first():
            flash("Ese usuario o correo ya está registrado.", "error")
        else:
            user = User(username=username, email=email, password_hash=generate_password_hash(password), credits=100)
            db.session.add(user); db.session.flush()
            db.session.add(CreditEvent(user_id=user.id, amount=100, reason="Bono de bienvenida"))
            db.session.commit()
            session.clear(); session["user_id"] = user.id
            flash("Cuenta creada. Recibiste 100 créditos de bienvenida.", "success")
            return redirect(url_for("dashboard"))
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        identity = request.form.get("identity", "").strip()
        user = User.query.filter((User.username == identity) | (User.email == identity.lower())).first()
        if user and check_password_hash(user.password_hash, request.form.get("password", "")):
            session.clear(); session["user_id"] = user.id
            flash("Sesión iniciada correctamente.", "success")
            return redirect(url_for("dashboard"))
        flash("Credenciales incorrectas.", "error")
    return render_template("auth.html", mode="login")

@app.post("/logout")
@login_required
def logout():
    session.clear()
    flash("Has cerrado sesión.", "success")
    return redirect(url_for("index"))

@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    projects = Project.query.filter_by(user_id=user.id).order_by(Project.created_at.desc()).limit(5).all()
    events = CreditEvent.query.filter_by(user_id=user.id).order_by(CreditEvent.created_at.desc()).limit(6).all()
    snippets_count = SavedSnippet.query.filter_by(user_id=user.id).count()
    return render_template("dashboard.html", projects=projects, events=events, snippets_count=snippets_count)

@app.route("/projects", methods=["GET", "POST"])
@login_required
def projects():
    user = current_user()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        desc = request.form.get("description", "").strip()
        if not name or len(name) > 80 or len(desc) > 300:
            flash("Revisa el nombre y la descripción del proyecto.", "error")
        else:
            db.session.add(Project(user_id=user.id, name=name, description=desc))
            db.session.commit()
            flash("Proyecto creado.", "success")
        return redirect(url_for("projects"))
    items = Project.query.filter_by(user_id=user.id).order_by(Project.created_at.desc()).all()
    return render_template("projects.html", projects=items)

@app.post("/projects/<int:project_id>/delete")
@login_required
def delete_project(project_id):
    item = Project.query.filter_by(id=project_id, user_id=current_user().id).first_or_404()
    db.session.delete(item); db.session.commit()
    flash("Proyecto eliminado.", "success")
    return redirect(url_for("projects"))

@app.route("/credits")
@login_required
def credits():
    user = current_user()
    events = CreditEvent.query.filter_by(user_id=user.id).order_by(CreditEvent.created_at.desc()).all()
    return render_template("credits.html", events=events)

@app.route("/code-lab", methods=["GET", "POST"])
@login_required
def code_lab():
    user = current_user()
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        language = request.form.get("language", "python")
        code = request.form.get("code", "")
        if title and len(title) <= 80 and code and len(code) <= 20000:
            db.session.add(SavedSnippet(user_id=user.id, title=title, language=language, code=code))
            db.session.commit()
            flash("Fragmento guardado.", "success")
        else:
            flash("Completa el título y mantén el código por debajo de 20.000 caracteres.", "error")
        return redirect(url_for("code_lab"))
    snippets = SavedSnippet.query.filter_by(user_id=user.id).order_by(SavedSnippet.created_at.desc()).all()
    return render_template("code_lab.html", snippets=snippets)

@app.post("/snippets/<int:snippet_id>/delete")
@login_required
def delete_snippet(snippet_id):
    item = SavedSnippet.query.filter_by(id=snippet_id, user_id=current_user().id).first_or_404()
    db.session.delete(item); db.session.commit()
    flash("Fragmento eliminado.", "success")
    return redirect(url_for("code_lab"))

@app.route("/security")
@login_required
def security():
    return render_template("security.html")

@app.route("/assistant", methods=["GET", "POST"])
@login_required
def assistant():
    answer = None
    if request.method == "POST":
        prompt = request.form.get("prompt", "").strip()[:1500]
        if prompt:
            answer = ("Asistente local de CART3R: organiza tu solicitud en objetivo, contexto y resultado esperado. "
                      "Para seguridad, trabaja únicamente con sistemas propios o con autorización explícita. "
                      "No ejecuto acciones externas ni accedo a cuentas de terceros. "
                      "Solicitud recibida: " + prompt)
    return render_template("assistant.html", answer=answer)

@app.route("/settings")
@login_required
def settings():
    return render_template("settings.html")

@app.errorhandler(404)
def not_found(_):
    return render_template("error.html", code=404, message="No encontramos esa página."), 404

@app.errorhandler(500)
def server_error(_):
    db.session.rollback()
    return render_template("error.html", code=500, message="Ocurrió un error interno."), 500

with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)), debug=False)
